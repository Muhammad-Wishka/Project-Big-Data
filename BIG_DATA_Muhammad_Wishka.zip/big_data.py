import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import fungsi
import tabel
import re
import textwrap

os.chdir("Project\PYTHON\RANDOM\BIG_DATA")
dataset = pd.read_csv("mie.csv")

while True:
    try:
        INPUTS = int(input("""Chart apa yang ingin anda lihat?
                        Ketik 1 untuk melihat chart jenis mie instan yang paling disukai
                        Ketik 2 untuk melihat chart frekuensi konsumsi mie instan
                        """))        
        assert INPUTS == 1 or INPUTS == 2, "Input harus 1 atau 2."        
        break
    except AssertionError as e:
        print(f"Terjadi kesalahan: {e}")
    except ValueError:
        print("Input harus berupa angka.")

pd.set_option('display.max_rows', None)
pd.set_option('display.max_colwidth', None)

dataset = dataset.rename(columns={
    "Nama (Inisial)":"Nama",
    "Apa merk dan varian mie instan favorit anda?": "Favorit",
    "Seberapa sering anda konsumsi mie instan?": "Frekuensi"
})

dataset["Nama"] = dataset["Nama"].str.upper().str[:3]
dupl = dataset["Nama"].duplicated(keep="first")
dataset.loc[dupl,"Nama"] = dataset.loc[dupl,"Nama"].str[:2]+"1"
dataset["Nama"] = dataset["Nama"].apply(lambda x: x if len(x) == 3 else x + "xx").str[:3]
dataset["Usia"] = dataset["Usia"].map(tabel.mapping_usia)
dataset["Frekuensi"] = dataset["Frekuensi"].map(tabel.mapping_frek)

dataset.insert(3,'Favorit_Kode',dataset['Favorit'])

dataset['Favorit_Kode']=(
    dataset['Favorit']
    .apply(lambda x: re.sub(r'[^a-zA-Z-, ]','',x))
    .replace(r" ","-", regex=True)
    .replace(r",","-", regex=True)
    .replace(r"--","-", regex=True)    
    .replace(r"--","-", regex=True)
    .str.strip("-")
    .replace(r"-","+", regex=True)
    .str.replace(r"indomi?e?","indomie",1, regex=True, case=False)
    .str.replace(r"sedaa?p","sedaap",1, regex=True, case=False)
    .str.replace(r"sarimie?","sarimi",1, regex=True, case=False)
    .str.replace(r"supermie?","supermi",1, regex=True, case=False)
    .str.replace(r"rebus|kuah","kuah",1, regex=True, case=False)
    .apply(fungsi.hapus_dobel)
)

for pattern, replacement in tabel.dictionary.items():
    dataset['Favorit_Kode'] = dataset['Favorit_Kode'].str.replace(pattern, replacement, regex=True, case=False)

dataset['Favorit_Kode'] =(
    dataset['Favorit_Kode']
    .apply(lambda x: re.sub(r'[^0-9+]','',x))
    .replace(r"\+\+","+", regex=True)
    .replace(r"\+\+","+", regex=True)
    .str.strip("+")
    .apply(fungsi.sums)
)

dataset.insert(4,'Jenis_Mie',dataset['Favorit_Kode'])
dataset["Jenis_Mie"] = dataset["Jenis_Mie"].apply(fungsi.ubah_string)

try:
    for pattern, replacement in tabel.konversi.items():
        dataset['Jenis_Mie'] = dataset['Jenis_Mie'].str.replace(pattern, replacement, regex=True, case=False)
except:
    dataset["Jenis_Mie"]

dataset = dataset[~dataset["Jenis_Mie"].apply(fungsi.hapus_angka_invalid)]
jumlah_jenis_mie = dataset['Jenis_Mie'].value_counts()
print(dataset)
print(jumlah_jenis_mie)

if INPUTS == 1:
    fig, ax = plt.subplots(figsize=(9, 7))  # Hanya satu subplot
    labels_jenis_mie = [f'{chr(65+i)}' for i in range(len(jumlah_jenis_mie))]
    wedges, texts, autotexts = ax.pie(jumlah_jenis_mie, labels=labels_jenis_mie, autopct='%1.1f%%', startangle=140)
    legend_labels_jenis_mie = [f"{label} - {name}" for label, name in zip(labels_jenis_mie, jumlah_jenis_mie.index)]
    ax.legend(wedges, legend_labels_jenis_mie, title="Jenis Mie", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
    ax.set_title('Distribusi Jenis Mie Favorit')
elif INPUTS == 2:
    fig, ax = plt.subplots(figsize=(9, 7))  # Hanya satu subplot
    jumlah_frekuensi = dataset['Frekuensi'].value_counts()
    labels_frekuensi = [f'{chr(65+i)}' for i in range(len(jumlah_frekuensi))]
    wedges, texts, autotexts = ax.pie(jumlah_frekuensi, labels=labels_frekuensi, autopct='%1.1f%%', startangle=140)
    legend_labels_frekuensi = [f"{label} - {tabel.inverse_mapping_frek[name]}" for label, name in zip(labels_frekuensi, jumlah_frekuensi.index)]
    ax.legend(wedges, legend_labels_frekuensi, title="Frekuensi Konsumsi", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
    ax.set_title('Distribusi Frekuensi Konsumsi')

plt.tight_layout()
plt.show()