import re

def hapus_dobel(x):
    words = x.split("+")
    seen = set()
    result = []
    for word in words:
        if word not in seen:
            seen.add(word)
            result.append(word)
    return "+".join(result)

def sums(x):
    summation = [int(num) for num in x.split("+") if num.isdigit()]
    return sum(summation)

def ubah_string(x):
    return str(x)

def ubah_int(x):
    return int(x)

def hapus_angka_invalid(x):
    return bool(re.fullmatch(r'\d+', x))